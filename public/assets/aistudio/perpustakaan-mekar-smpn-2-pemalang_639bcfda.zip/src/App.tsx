import React, { useState } from 'react';
import { LibraryProvider } from './context/LibraryContext';
import { Header } from './components/Header';
import { Navigation, MainTabType } from './components/Navigation';
import { VisitorKioskView } from './components/kiosk/VisitorKioskView';
import { AdminLoginModal } from './components/auth/AdminLoginModal';
import { BookCollectionModule } from './components/modules/BookCollectionModule';
import { CirculationModule } from './components/modules/CirculationModule';
import { MembershipModule } from './components/modules/MembershipModule';
import { VisitorModule } from './components/modules/VisitorModule';
import { CatalogSearchModule } from './components/modules/CatalogSearchModule';
import { InventoryReportingModule } from './components/modules/InventoryReportingModule';
import { LiteracyProgramModule } from './components/modules/LiteracyProgramModule';
import { AdminManagementModule } from './components/modules/AdminManagementModule';
import { BackupDriveModule } from './components/modules/BackupDriveModule';
import { SCHOOL_INFO } from './types/library';

export default function App() {
  // Mode: 'pengunjung' (default public kiosk) vs 'admin' (authenticated management)
  const [viewMode, setViewMode] = useState<'pengunjung' | 'admin'>('pengunjung');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);

  // Active Tab when in Admin Mode
  const [activeTab, setActiveTab] = useState<MainTabType>('koleksi');

  const handleLoginSuccess = () => {
    setIsAdminLoggedIn(true);
    setViewMode('admin');
    setShowLoginModal(false);
  };

  const handleLogoutToKiosk = () => {
    setViewMode('pengunjung');
  };

  return (
    <LibraryProvider>
      <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans antialiased">
        {/* TAMPILAN 1: KIOSK PENGUNJUNG / BUKU TAMU DIGITAL (DEFAULT AWAL) */}
        {viewMode === 'pengunjung' ? (
          <div className="flex-1 p-4 sm:p-6 lg:p-8 flex flex-col justify-between">
            <VisitorKioskView onOpenAdminLogin={() => setShowLoginModal(true)} />

            {/* Kiosk Footer */}
            <footer className="mt-8 text-center text-xs text-slate-500 border-t border-slate-200 pt-4">
              <p className="font-bold text-slate-800">
                {SCHOOL_INFO.libraryName} • {SCHOOL_INFO.name}
              </p>
              <p className="text-[11px] text-slate-500">
                NPSN: {SCHOOL_INFO.npsn} | {SCHOOL_INFO.address}
              </p>
              <button
                onClick={() => setShowLoginModal(true)}
                className="mt-2 text-[11px] text-emerald-800 hover:text-emerald-950 font-bold underline cursor-pointer"
              >
                Masuk ke Panel Administrasi Perpustakaan (Khusus Petugas)
              </button>
            </footer>
          </div>
        ) : (
          /* TAMPILAN 2: PANEL LENGKAP ADMIN PERPUSTAKAAN */
          <>
            {/* Top Admin Header */}
            <Header
              onNavigateTab={(tab) => setActiveTab(tab as MainTabType)}
              onSwitchToVisitorKiosk={handleLogoutToKiosk}
            />

            {/* 8-Module Navigation */}
            <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

            {/* Main Content Area */}
            <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
              {activeTab === 'koleksi' && <BookCollectionModule />}
              {activeTab === 'sirkulasi' && <CirculationModule />}
              {activeTab === 'keanggotaan' && <MembershipModule />}
              {activeTab === 'pengunjung' && <VisitorModule />}
              {activeTab === 'katalog' && (
                <CatalogSearchModule onDirectBorrow={() => setActiveTab('sirkulasi')} />
              )}
              {activeTab === 'laporan' && <InventoryReportingModule />}
              {activeTab === 'literasi' && <LiteracyProgramModule />}
              {activeTab === 'administrasi' && <AdminManagementModule />}
              {activeTab === 'backup' && <BackupDriveModule />}
            </main>

            {/* Admin Footer */}
            <footer className="bg-white border-t border-slate-200 py-6 px-4 text-center text-xs text-slate-500 no-print mt-auto">
              <div className="max-w-7xl mx-auto space-y-1">
                <p className="font-bold text-slate-800">
                  {SCHOOL_INFO.libraryName} • {SCHOOL_INFO.name} (Panel Administrator)
                </p>
                <p>
                  NPSN: <span className="font-semibold text-slate-700">{SCHOOL_INFO.npsn}</span> | {SCHOOL_INFO.address}
                </p>
                <p className="text-[11px] text-emerald-800 font-medium">
                  Motto: "{SCHOOL_INFO.motto}"
                </p>
              </div>
            </footer>
          </>
        )}

        {/* Modal Login Admin dengan Password NPSN (20324292) */}
        <AdminLoginModal
          isOpen={showLoginModal}
          onClose={() => setShowLoginModal(false)}
          onLoginSuccess={handleLoginSuccess}
        />
      </div>
    </LibraryProvider>
  );
}
